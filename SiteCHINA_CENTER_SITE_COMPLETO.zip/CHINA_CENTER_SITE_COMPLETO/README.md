# China Center — Site completo

Projeto responsivo da China Center, com páginas institucionais, catálogo visual e central interativa de promoções.

## Páginas

- Página inicial
- Utilidades
- Decoração
- Flores artificiais
- Nossa loja
- Central de promoções interativa

## Recursos

- Layout adaptado para celular, tablet e computador
- Imagens da loja e do catálogo
- Animações e faixas publicitárias
- Filtros de campanhas por categoria
- Lista interativa de ofertas
- Modal com detalhes das campanhas

## Como executar

Requisito: Node.js 22 ou superior.

```bash
npm install
npm run dev
```

Abra o endereço exibido no terminal.

## Gerar versão de produção

```bash
npm run build
npm run start
```

## Estrutura principal

- `app/`: páginas, componentes e estilos
- `public/`: imagens e identidade visual
- `components/`: componentes reutilizáveis
- `package.json`: dependências e comandos do projeto

© China Center — Utilidades, Decorações e Atacado.
