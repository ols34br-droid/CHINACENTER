import Link from "next/link";

export function SiteHeader() {
  return <header className="site-header">
    <Link className="brand" href="/" aria-label="China Center - início"><span className="brand-mark">CC</span><span>CHINA <b>CENTER</b></span></Link>
    <nav aria-label="Navegação principal"><Link href="/utilidades">Utilidades</Link><Link href="/decoracao">Decoração</Link><Link href="/flores-artificiais">Flores</Link><Link href="/nossa-loja">Nossa loja</Link><Link className="nav-cta promo-nav" href="/promocoes">Promoções</Link></nav>
  </header>;
}

export function SiteFooter() {
  return <footer><div className="footer-brand"><span className="brand-mark">CC</span><span>CHINA <b>CENTER</b></span></div><p>Utilidades • Decorações • Flores artificiais • Atacado</p><p>Tem de tudo. <b>Tem pra você.</b></p></footer>;
}
