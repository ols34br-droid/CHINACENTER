"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { ArrowUpRight, Check, Copy, ShoppingBag, Sparkles, Trash2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type Offer = { id:string; title:string; category:string; label:string; image:string; text:string };

const offers: Offer[] = [
  { id:"mesa", title:"Mesa posta", category:"cozinha", label:"PREÇO ESPECIAL", image:"/catalogo/utilidades.png", text:"Louças, copos e acessórios selecionados para renovar sua mesa." },
  { id:"potes", title:"Organização de cozinha", category:"cozinha", label:"OFERTA NA LOJA", image:"/catalogo/setor-utilidades.jpeg", text:"Potes, organizadores e soluções práticas para sua rotina." },
  { id:"casa", title:"Casa organizada", category:"casa", label:"SELEÇÃO DA SEMANA", image:"/catalogo/corredor.jpeg", text:"Itens para otimizar espaços e deixar tudo no lugar." },
  { id:"decor", title:"Detalhes que transformam", category:"decoracao", label:"DESTAQUE", image:"/catalogo/arvore-flores.jpeg", text:"Vasos, objetos e peças decorativas para todos os estilos." },
  { id:"flores", title:"Flores artificiais", category:"flores", label:"COLEÇÃO ESPECIAL", image:"/catalogo/flores-artificiais.png", text:"Arranjos, hastes e folhagens com beleza em todas as estações." },
  { id:"lar", title:"Utilidades para o lar", category:"casa", label:"MAIS POR MENOS", image:"/catalogo/setor-lar.jpeg", text:"Escolhas inteligentes para facilitar cada ambiente da casa." },
];

const tabs = [{value:"todos",label:"Todas"},{value:"cozinha",label:"Cozinha"},{value:"casa",label:"Casa"},{value:"decoracao",label:"Decoração"},{value:"flores",label:"Flores"}];

export function PromotionsExperience() {
  const [selected,setSelected]=useState<string[]>([]);
  const [detail,setDetail]=useState<Offer|null>(null);
  const [copied,setCopied]=useState(false);
  const selectedOffers=useMemo(()=>offers.filter(item=>selected.includes(item.id)),[selected]);
  const toggle=(id:string)=>setSelected(current=>current.includes(id)?current.filter(item=>item!==id):[...current,id]);
  const surprise=()=>setDetail(offers[Math.floor(Math.random()*offers.length)]);
  const copyList=async()=>{if(!selectedOffers.length)return;await navigator.clipboard.writeText(`Minha lista China Center:\n${selectedOffers.map(item=>`• ${item.title}`).join("\n")}\n\nConsulte disponibilidade e condições na loja.`);setCopied(true);window.setTimeout(()=>setCopied(false),1800)};

  const renderCards=(filter:string)=><div className="promo-grid">{offers.filter(item=>filter==="todos"||item.category===filter).map((offer,index)=><article className="offer-card" key={offer.id} style={{animationDelay:`${index*70}ms`}}>
    <div className="offer-image"><Image src={offer.image} alt={offer.title} fill sizes="(max-width: 760px) 100vw, 33vw"/><span>{offer.label}</span></div>
    <div className="offer-body"><p>{offer.category}</p><h3>{offer.title}</h3><div className="offer-actions"><button onClick={()=>setDetail(offer)}>Ver detalhes <ArrowUpRight /></button><button className={selected.includes(offer.id)?"offer-add active":"offer-add"} onClick={()=>toggle(offer.id)} aria-label={selected.includes(offer.id)?`Remover ${offer.title} da lista`:`Adicionar ${offer.title} à lista`}>{selected.includes(offer.id)?<Check/>:"+"}</button></div></div>
  </article>)}</div>;

  return <>
    <section className="promo-hero">
      <div className="promo-orbit orbit-one"/><div className="promo-orbit orbit-two"/>
      <div className="promo-hero-copy"><p className="promo-live"><span/> OFERTAS EM DESTAQUE</p><h1>Preço baixo.<br/><em>Escolhas gigantes.</em></h1><p>Explore as campanhas, selecione seus favoritos e leve sua lista pronta para a China Center.</p><div className="promo-hero-actions"><a href="#ofertas" className="button primary">Explorar ofertas <span>↓</span></a><button className="button promo-surprise" onClick={surprise}><Sparkles/> Me surpreenda</button></div></div>
      <div className="promo-hero-panel"><div className="panel-top"><span>CHINA CENTER</span><span className="panel-pulse">AO VIVO</span></div><div className="big-offer"><strong>OFERTAS</strong><em>DA SEMANA</em></div><div className="panel-bottom"><span>UTILIDADES</span><span>DECORAÇÃO</span><span>FLORES</span></div></div>
    </section>

    <div className="promo-marquee" aria-hidden="true"><div>PREÇO BAIXO • NOVIDADES • UTILIDADES • DECORAÇÃO • FLORES ARTIFICIAIS • TEM DE TUDO, TEM PRA VOCÊ • PREÇO BAIXO • NOVIDADES • UTILIDADES • DECORAÇÃO • FLORES ARTIFICIAIS •</div></div>

    <section className="promo-workspace" id="ofertas">
      <div className="promo-workspace-head"><div><p className="section-kicker">CENTRAL DE OFERTAS</p><h2>Monte sua rota de compras.</h2></div><div className="offer-counter"><strong>{String(offers.length).padStart(2,"0")}</strong><span>campanhas<br/>em destaque</span></div></div>
      <div className="promo-layout">
        <Tabs defaultValue="todos" className="promo-tabs"> <TabsList className="promo-tabs-list">{tabs.map(tab=><TabsTrigger key={tab.value} value={tab.value}>{tab.label}</TabsTrigger>)}</TabsList>{tabs.map(tab=><TabsContent key={tab.value} value={tab.value}>{renderCards(tab.value)}</TabsContent>)}</Tabs>
        <aside className="shopping-list"><div className="list-head"><span><ShoppingBag/> MINHA LISTA</span><b>{selected.length}</b></div>{selectedOffers.length===0?<div className="list-empty"><span>＋</span><p>Adicione ofertas para montar sua rota pela loja.</p></div>:<div className="list-items">{selectedOffers.map((item,index)=><div key={item.id}><span>0{index+1}</span><p>{item.title}</p><button onClick={()=>toggle(item.id)} aria-label={`Remover ${item.title}`}><Trash2/></button></div>)}</div>}<div className="list-progress"><span style={{width:`${Math.min(selected.length/4*100,100)}%`}}/></div><p className="progress-copy">{selected.length>=4?"Lista completa para sua visita!":`${4-selected.length} seleções para completar sua rota`}</p><button className="copy-list" disabled={!selected.length} onClick={copyList}>{copied?<><Check/> Lista copiada</>:<><Copy/> Copiar minha lista</>}</button><small>Disponibilidade e condições devem ser confirmadas na loja.</small></aside>
      </div>
    </section>

    <section className="promo-banner"><div><span>OFERTA BOA É OFERTA ENCONTRADA</span><h2>Tem de tudo.<br/>Tem pra você.</h2></div><div className="promo-stamp"><span>CC</span><strong>PREÇO<br/>BAIXO</strong></div></section>

    <Dialog open={!!detail} onOpenChange={open=>!open&&setDetail(null)}><DialogContent className="promo-dialog">{detail&&<><div className="dialog-image"><Image src={detail.image} alt={detail.title} fill sizes="560px"/></div><DialogHeader><p>{detail.label}</p><DialogTitle>{detail.title}</DialogTitle><DialogDescription>{detail.text} Consulte disponibilidade, valores e condições diretamente na loja.</DialogDescription></DialogHeader><button className={selected.includes(detail.id)?"dialog-add active":"dialog-add"} onClick={()=>toggle(detail.id)}>{selected.includes(detail.id)?<><Check/> Adicionado à minha lista</>:<><ShoppingBag/> Adicionar à minha lista</>}</button></>}</DialogContent></Dialog>
  </>;
}
