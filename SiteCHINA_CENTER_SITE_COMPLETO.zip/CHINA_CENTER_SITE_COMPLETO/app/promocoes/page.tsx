import type { Metadata } from "next";
import { SiteFooter, SiteHeader } from "../site-shell";
import { PromotionsExperience } from "./promotions-experience";

export const metadata: Metadata = {
  title: "Promoções | China Center",
  description: "Explore as campanhas e monte sua lista de ofertas da China Center.",
};

export default function PromotionsPage() {
  return <main className="promo-page"><SiteHeader /><PromotionsExperience /><SiteFooter /></main>;
}
