import Image from "next/image";
import Link from "next/link";
import { SiteFooter, SiteHeader } from "./site-shell";

const categories = [
  { title: "Cozinha", text: "Organização, preparo e itens para servir bem.", icon: "◒" },
  { title: "Casa & organização", text: "Soluções práticas para deixar tudo em seu lugar.", icon: "⌂" },
  { title: "Decoração", text: "Detalhes que transformam ambientes e criam aconchego.", icon: "✦" },
  { title: "Limpeza", text: "Produtos úteis para facilitar a rotina da sua casa.", icon: "◇" },
];

export default function Home() {
  return (
    <main>
      <SiteHeader />

      <section className="hero" id="inicio">
        <Image src="/products/loja-hero.jpeg" alt="Interior da China Center com utilidades e decoração" fill priority sizes="100vw" />
        <div className="hero-shade" />
        <div className="hero-content">
          <p className="eyebrow">UTILIDADES • DECORAÇÃO • ATACADO</p>
          <h1>Tem de tudo.<br /><em>Tem pra você.</em></h1>
          <p className="hero-copy">Variedade para a casa inteira, preço baixo e novidades para todos os estilos.</p>
          <div className="hero-actions"><a className="button primary" href="#categorias">Ver categorias <span>↘</span></a><a className="button ghost" href="#visite">Conhecer a loja</a></div>
        </div>
        <div className="hero-stat"><strong>TODO DIA</strong><span>novas escolhas para sua casa</span></div>
      </section>

      <section className="home-promo"><div><p>OFERTAS EM DESTAQUE</p><h2>Uma central de promoções feita para você.</h2><span>Filtre campanhas, salve seus favoritos e monte sua lista antes de visitar a loja.</span></div><Link href="/promocoes">EXPLORAR AGORA <b>→</b></Link></section>

      <section className="intro" id="categorias">
        <p className="section-kicker">ENCONTRE O QUE PRECISA</p>
        <div className="section-heading"><h2>Da rotina aos detalhes que fazem a diferença.</h2><p>Uma seleção completa para organizar, decorar e renovar seus ambientes com praticidade.</p></div>
        <div className="category-grid">
          {categories.map((category, index) => <article className="category-card" key={category.title}>
            <span className="card-number">0{index + 1}</span><span className="card-icon" aria-hidden="true">{category.icon}</span><h3>{category.title}</h3><p>{category.text}</p><Link href={category.title==="Decoração"?"/decoracao":"/utilidades"}>Descobrir <span>→</span></Link>
          </article>)}
        </div>
      </section>

      <section className="showcase" id="sobre">
        <div className="showcase-art"><Image src="/products/loja-mobile.jpeg" alt="Setor de utilidades da China Center" fill sizes="(max-width: 900px) 100vw, 50vw" /><span className="vertical-copy">CHINA CENTER • UTILIDADES</span></div>
        <div className="showcase-copy">
          <p className="section-kicker">MUITO MAIS POR MENOS</p><h2>Uma loja feita para quem gosta de escolher bem.</h2>
          <p>Praticidade, variedade e preço baixo reunidos em um só lugar. Aqui você encontra soluções para o dia a dia e peças para dar personalidade à sua casa.</p>
          <ul><li><span>01</span><div><strong>Variedade de verdade</strong><p>Opções para diferentes necessidades e estilos.</p></div></li><li><span>02</span><div><strong>Preço que cabe no bolso</strong><p>Boas escolhas para renovar sem complicação.</p></div></li><li><span>03</span><div><strong>Compra prática</strong><p>Tudo organizado para você encontrar com facilidade.</p></div></li></ul>
        </div>
      </section>

      <section className="departments"><p>ESCOLHA SEU JEITO DE COMPRAR</p><div className="department-grid">
        <article><Image src="/products/logo-utilitarios.jpeg" alt="China Center Utilitários" fill sizes="(max-width: 700px) 100vw, 33vw" /></article>
        <article><Image src="/products/logo-decoracoes.jpeg" alt="China Center Decorações" fill sizes="(max-width: 700px) 100vw, 33vw" /></article>
        <article><Image src="/products/logo-atacado.jpeg" alt="China Center Atacado" fill sizes="(max-width: 700px) 100vw, 33vw" /></article>
      </div></section>

      <section className="visit" id="visite"><div><p className="section-kicker light">VENHA DESCOBRIR</p><h2>Sua próxima escolha favorita está aqui.</h2></div><Link className="button light-button" href="/nossa-loja">Explorar a China Center <span>→</span></Link></section>
      <SiteFooter />
    </main>
  );
}
