import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "China Center | Utilitários e Decorações", description: "Utilidades, decoração e atacado. Tem de tudo, tem pra você.", icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt-BR"><body>{children}</body></html>; }
