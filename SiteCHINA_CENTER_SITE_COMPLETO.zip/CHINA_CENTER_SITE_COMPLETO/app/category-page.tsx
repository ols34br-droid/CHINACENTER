import Image from "next/image";
import Link from "next/link";
import { SiteFooter, SiteHeader } from "./site-shell";

type Props = { eyebrow:string; title:string; lead:string; image:string; imageAlt:string; items:string[]; note:string; gallery?:{src:string;alt:string}[] };

export function CategoryPage({ eyebrow,title,lead,image,imageAlt,items,note,gallery=[] }:Props) {
  return <main><SiteHeader />
    <section className="inner-hero"><Image src={image} alt={imageAlt} fill priority sizes="100vw"/><div className="inner-overlay"/><div className="inner-copy"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{lead}</p><a className="button primary" href="#colecao">Ver coleção <span>↓</span></a></div></section>
    <section className="collection" id="colecao"><div className="collection-head"><p className="section-kicker">ENCONTRE NA CHINA CENTER</p><h2>Escolhas para todos os cantos da casa.</h2></div><div className="item-list">{items.map((item,index)=><article key={item}><span>0{index+1}</span><h3>{item}</h3><p>Variedade, praticidade e opções para combinar com seu estilo.</p></article>)}</div></section>
    {gallery.length>0 && <section className="photo-gallery">{gallery.map((photo,index)=><figure key={photo.src} className={index===0?"gallery-wide":""}><Image src={photo.src} alt={photo.alt} fill sizes="(max-width: 800px) 100vw, 50vw"/></figure>)}</section>}
    <section className="category-note"><p className="section-kicker light">VARIEDADE TODO DIA</p><h2>{note}</h2><Link className="button light-button" href="/nossa-loja">Conheça nossa loja <span>→</span></Link></section>
    <SiteFooter />
  </main>;
}
